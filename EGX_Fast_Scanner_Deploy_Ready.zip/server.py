from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import requests, os

app=FastAPI(title="EGX Fast Scanner")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_methods=["*"],allow_headers=["*"])

TV_URL="https://scanner.tradingview.com/egypt/scan"
COLUMNS=["name","description","close","change","volume","relative_volume_10d_calc","Value.Traded","high","low"]

@app.get("/")
def root(): return {"ok":True,"service":"EGX Fast Scanner","endpoint":"/api/scan"}

@app.get("/api/health")
def health(): return {"ok":True,"source":"TradingView EGX scanner"}

@app.get("/api/scan")
def scan():
    payload={"filter":[],"options":{"lang":"en"},"markets":["stock"],
             "symbols":{"query":{"types":[]},"tickers":[]},
             "columns":COLUMNS,"sort":{"sortBy":"change","sortOrder":"desc"},"range":[0,300]}
    r=requests.post(TV_URL,json=payload,timeout=20)
    r.raise_for_status()
    raw=r.json()
    rows=[]
    for item in raw.get("data",[]):
        d=item.get("d",[])
        if len(d)<len(COLUMNS): continue
        x=dict(zip(COLUMNS,d))
        rows.append({
          "symbol":item.get("s","").split(":")[-1],
          "name":x.get("description") or x.get("name"),
          "price":x.get("close"),"change":x.get("change"),
          "volume":x.get("volume"),"volume_ratio":x.get("relative_volume_10d_calc"),
          "turnover":x.get("Value.Traded"),"high":x.get("high"),"low":x.get("low")
        })
    return {"source":"TradingView","market":"EGX","count":len(rows),"data":rows}
